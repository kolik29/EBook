export interface Book {
    id: number;
    title: string;
    author: string;
    img: string;
    active: boolean;
}