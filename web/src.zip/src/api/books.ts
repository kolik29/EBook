import type { Book } from '../types/book';

const API_URL = 'http://localhost:3000';

const mockBooks: Book[] = Array(200).fill({
    id: 1,
    title: "Harry Potter and the Sorcerer's Stone",
    author: 'JK Rowling',
    img: 'https://images.booksense.com/images/403/353/9780590353403.jpg',
    active: false,
});

export const getBooks = async (): Promise<Book[]> => {
    try {
        const res = await fetch(`${API_URL}/books`);
        if (!res.ok) throw new Error();
        return res.json();
    } catch {
        return mockBooks;
    }
};