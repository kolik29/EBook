import WifiIcon from '@mui/icons-material/Wifi';
import WifiOffIcon from '@mui/icons-material/WifiOff';
import ScreenRotationIcon from '@mui/icons-material/ScreenRotation';
import UploadIcon from '@mui/icons-material/Upload';
import RefreshIcon from '@mui/icons-material/Refresh';
import { Box, IconButton } from '@mui/material';
import clsx from 'clsx';
import { useRef, useState } from 'react';

const ICON_SIZE = 30;
const iconSx = { fontSize: ICON_SIZE };

const ActionBar = () => {
    const [disabledWiFi, setDisabledWiFi] = useState(false);
    const [rotateDisplay, setRotateDisplay] = useState(false);
    const [refreshDisplay, setRefreshDisplay] = useState(false);

    const fileInputRef = useRef<HTMLInputElement>(null);

    const handleDisableWiFi = () => {
        setDisabledWiFi(true);
    }

    const handleRotateDisplay = () => {
        console.log('rotate');
        setRotateDisplay(true);
    }

    const handleRefreshDisplay = () => {
        console.log('refresh');
        setRefreshDisplay(true);
    }

    const handleUploadBook = () => {
        console.log('upload');
        fileInputRef.current?.click();
    }

    const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
        const file = e.target.files?.[0];
        if (!file) return;
        console.log('file:', file);
    };

    return (
        <Box sx={{ p: 1 }} className={clsx('display__flex justify-content__space-around')}>
            <IconButton onClick={handleDisableWiFi}>
                {disabledWiFi ? <WifiOffIcon sx={iconSx} /> : <WifiIcon sx={iconSx} />}
            </IconButton>
            <IconButton onClick={handleRotateDisplay}>
                <ScreenRotationIcon
                    sx={iconSx}
                    className={clsx({ 'spin': rotateDisplay })}
                    onAnimationEnd={() => setRotateDisplay(false)}
                />
            </IconButton>
            <IconButton onClick={handleRefreshDisplay}>
                <RefreshIcon
                    sx={iconSx}
                    className={clsx({ 'spin': refreshDisplay })}
                    onAnimationEnd={() => setRefreshDisplay(false)}
                />
            </IconButton>
            <IconButton onClick={handleUploadBook}>
                <UploadIcon sx={iconSx} />
            </IconButton>
            <input
                ref={fileInputRef}
                type="file"
                hidden
                onChange={handleFileChange}
            />
        </Box>
    )
};

export default ActionBar;
