import styles from './styles.module.sass';
import { Box, Stack, Typography } from '@mui/material';
import CheckIcon from '@mui/icons-material/Check';
import clsx from 'clsx';

const BookCard = ({ img, title, active }: { id: number; img: string; title: string; active: boolean }) => {
    return (
        <Box className={clsx(styles.item)}>
            <Box className={clsx('position__relative')}>
                <img src={img} alt={title} className={clsx(styles.image)} />
                {active &&
                <Stack
                    sx={{
                        justifyContent: 'center',
                        alignItems: 'center',
                    }}
                    className={clsx('position__absolute', 'width__100', 'height__100', 'top__0', 'left__0', styles.active)}>
                        <CheckIcon />
                </Stack>}
            </Box>
            <Typography variant='h2' sx={{ fontSize: 16 }} className={clsx('text-align__center', styles.title)}>
                {title}
            </Typography>
        </Box>
    )
};

export default BookCard;
