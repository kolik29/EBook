import styles from './styles.module.sass';
import BookItem from '../BookCard';
import { Swiper, SwiperSlide } from 'swiper/react';
import { FreeMode, Mousewheel } from 'swiper/modules';

import 'swiper/css';
import { Box, CircularProgress, Stack } from '@mui/material';
import clsx from 'clsx';
import type { Book } from '../../../types/book';
import { useEffect, useState } from 'react';
import { getBooks } from '../../../api/books';

const BookCatalog = () => {
    const [books, setBooks] = useState<Book[]>([]);
    const [loading, setLoading] = useState(true);

    useEffect(() => {
        getBooks()
            .then(setBooks)
            .finally(() => setLoading(false));
    }, []);

    if (loading) return (
        <Stack className={clsx('height__100', 'align-items__center', 'justify-content__center')}>
            <CircularProgress />
        </Stack>
    )

    const mobileSlides = books.map((book, i) => (
        <SwiperSlide key={book.id} className={clsx(styles.slideMobile)}>
            <BookItem id={book.id} img={book.img} title={book.title} active={book.active} />
        </SwiperSlide>
    ));

    return (
        <>
            <Swiper
                className={clsx('display__none--xs', styles.swiperDesktop)}
                modules={[FreeMode, Mousewheel]}
                direction='vertical'
                slidesPerView='auto'
                freeMode={{
                    enabled: true,
                    sticky: false,
                    momentum: true
                }}
                mousewheel={{
                    enabled: true,
                    forceToAxis: true,
                    releaseOnEdges: true,
                    sensitivity: 1
                }}
                watchOverflow
                observer
                observeParents
            >
                <SwiperSlide className={clsx(styles.desktopSlide)}>
                    <Box className={clsx(styles.catalogGrid)}>
                        {books.map((book, i) => (
                            <BookItem
                                key={book.id}
                                id={book.id}
                                img={book.img}
                                title={book.title}
                                active={book.active}
                            />
                        ))}
                    </Box>
                </SwiperSlide>
            </Swiper>

            <Swiper
                className={clsx('display__none--md', styles.swiperMobile)}
                modules={[FreeMode]}
                slidesPerView='auto'
                spaceBetween={16}
                freeMode={{
                    enabled: true,
                    momentum: true
                }}
            >
                {mobileSlides}
            </Swiper>
        </>
    )
};

export default BookCatalog;